# Track 3: egocentric reconstruction and transfer

Run the commands below from the submission kit root. Track 3 requires **two separate files**:
one CSV of policy rollout object poses for five metric competitions, and one Parquet of
reconstructed object meshes for the CD-O competition. The uploader sends each file to the
matching competitions.

[Metric scoring code](../../metric_code/track_3/) includes code-only copies of the six scorers.

## Pose submission: what you need

1. Reconstruct the scene from the released egocentric videos, train a policy for each scored
   episode, and run the included `flash_chord/scripts/evaluate_policy.py` in a compatible
   FlashCHORD environment with leaderboard trajectory export support. `examples/run_policy_evaluation.py` evaluates a JSON map of episode IDs to
   checkpoints. Produce one `episode_XXXXXX.parquet` trajectory per scored episode.
2. Install the kit dependencies with `pip install -r requirements.txt`. The packer checks
   every trajectory against the public row roster `data/track_3_sample_submission.csv` and the
   object order in `data/track_3_evaluation_objects.json`. Kaggle computes the pose metrics
   against the confidential reference after upload.
3. Set `COMMIT_URL` to your GitHub `/commit/<sha>` URL. The CSV records each episode's policy checkpoint
   SHA-256, the evaluator script and code SHA-256, and the packer and uploader script SHA-256.
   The scorer collects these hashes as provenance.

```bash
python3 examples/run_policy_evaluation.py \
  --checkpoints /path/to/checkpoints.json --results results/
python3 tools/pack_submission.py --track track_3 \
  --results results/ \
  --code-commit "$COMMIT_URL" \
  -o track3_poses.csv
python3 submit/v2d_submit.py track3_poses.csv --track track_3 -m "Track 3 rollout"
```

Accept the rules for all five Track 3 pose competitions before uploading. One rigid rotation
and translation per evaluation world align the first scored pose of object slot 0 to the
reference, then all objects and frames are scored. **Trajectory scale error remains scored.**

## Mesh submission: what you need

Reconstruct one triangle mesh for each `(episode, object)` listed in
`data/track_3_evaluation_objects.json`. Name files
`episode_XXXXXX/<object_name>.glb` (or `.obj`, `.ply`, `.stl`, `.off`) under one mesh directory.
The packer decimates and pads them to the fixed budget in
`data/track_3_mesh_sample_submission.parquet`. This file has a commit URL; policy and evaluator
hashes identify the pose rollout; the mesh CD-O file carries the producing commit URL.

```bash
python3 tools/pack_reconstruction.py track3-meshes \
  --meshes /path/to/track3_meshes \
  --sample data/track_3_mesh_sample_submission.parquet \
  --commit "$COMMIT_URL" \
  --out track3_meshes.parquet
python3 submit/v2d_submit.py track3_meshes.parquet --track track_3_mesh -m "Track 3 meshes"
```

Accept the CD-O competition rules before uploading the mesh file.

## How the six metrics are computed

The host scores pose metrics against confidential object trajectories and CD-O against
confidential scanned meshes. It averages pose scores over episodes. AUC, SP-SR, and MP-SR are
**higher is better**; RPE, MPPE, and CD-O are **lower is better**.

| Metric | What it measures |
|---|---|
| AUC | ADD accuracy integrated over 1 to 9 cm thresholds, using fixed points transformed by predicted and reference object poses. |
| SP-SR | Fraction of episodes with mean position error at most 10 cm and mean orientation error at most 0.5 radians. |
| MP-SR | Fraction of episodes where every tracked object has mean position error under 3 cm and orientation error under 30 degrees. |
| RPE | Mean error in one object's position expressed in another object's frame, in cm. A single-object episode contributes zero. |
| MPPE | Mean position error of six object-attached points 5 cm from each origin, in cm. |
| CD-O | Symmetric Chamfer distance between reconstructed and scanned mesh surfaces, in cm, after separate Sim(3) registration of each shape. Averaged over episode-object pairs. |

## Kaggle metric leaderboards

| Group | Metric | Kaggle leaderboard |
| --- | --- | --- |
| Pose | AUC | [v2d-challenge-track3-auc](https://www.kaggle.com/competitions/v2d-challenge-track3-auc/leaderboard) |
| Pose | SP-SR | [v2d-challenge-track3-sp-sr](https://www.kaggle.com/competitions/v2d-challenge-track3-sp-sr/leaderboard) |
| Pose | MP-SR | [v2d-challenge-track3-mp-sr](https://www.kaggle.com/competitions/v2d-challenge-track3-mp-sr/leaderboard) |
| Pose | RPE | [v2d-challenge-track3-rpe](https://www.kaggle.com/competitions/v2d-challenge-track3-rpe/leaderboard) |
| Pose | MPPE | [v2d-challenge-track3-mppe](https://www.kaggle.com/competitions/v2d-challenge-track3-mppe/leaderboard) |
| Mesh | CD-O | [v2d-challenge-track3-cd-o](https://www.kaggle.com/competitions/v2d-challenge-track3-cd-o/leaderboard) |

Check your scores and the combined standings on the
[V2D Challenge leaderboard](https://nvidia-isaac.github.io/video_to_data/v2d_challenge/#leaderboard).
