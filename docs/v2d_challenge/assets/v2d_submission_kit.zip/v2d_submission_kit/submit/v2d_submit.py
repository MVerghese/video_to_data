#!/usr/bin/env python3
"""Submit one V2D Challenge submission.csv to every leaderboard of a track.

Kaggle has no batch-submit endpoint, so the fan-out happens here. One track has one
submission file and several leaderboards (one Kaggle competition per metric), and the
identical file goes to all of them.

    python submit/v2d_submit.py submission.csv --track track_3 -m "sac, 40M steps"
    python submit/v2d_submit.py submission.csv --track track_3 -m "retry" --only add_auc
    python submit/v2d_submit.py submission.csv --track track_3 -m "..." --wait

Design notes, each of which exists because of a specific failure mode:

* **The file is validated locally first.** A malformed CSV that Kaggle rejects still consumes
  a submission from your daily quota on every competition it reached. Catching it here costs
  nothing.
* **Every competition is preflighted before anything is submitted.** The fan-out is not
  atomic, and the usual failure is unaccepted competition rules. Preflighting means that
  failure lands before the first submission rather than halfway through the loop, leaving you
  with a half-updated set of leaderboards.
* **Identity is checked across competitions.** The pooled leaderboard on the challenge site is
  joined across competitions on your Kaggle identity. If your team name differs between
  competitions you would silently appear as two separate entries. This turns that into a loud
  error here.
* **Only HTTP 429 is retried.** A dropped leg of the fan-out is exactly what desynchronises
  the pooled board, so rate limiting backs off and retries while every other error surfaces
  immediately with the ready-to-paste command that retries just the failed metrics.

Authentication: run ``kaggle auth login``, or set ``KAGGLE_API_TOKEN``, or put the token in
``~/.kaggle/access_token``. The legacy ``kaggle.json`` path is gone in kaggle >= 2.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np
import pandas as pd

from v2dlb import object_pose as op
from v2dlb import report_schema as rs

POSE_COLUMNS = op._POSE_COLUMNS
SUBMISSION_COLUMNS = [*POSE_COLUMNS, *rs.PROVENANCE_COLUMNS]

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "config" / "tracks.json"

_MAX_RATE_LIMIT_RETRIES = 5
_BACKOFF_BASE_SECONDS = 5.0
_POLL_SECONDS = 20
_POLL_TIMEOUT_SECONDS = 1800


def build_api():
    """Authenticate without importing the ``kaggle`` package root.

    ``import kaggle`` authenticates as an import side effect and raises before we can print a
    useful message, so go straight to the class.
    """
    from kaggle.api.kaggle_api_extended import KaggleApi

    api = KaggleApi()
    try:
        api.authenticate()
    except Exception as error:  # noqa: BLE001 - the message matters more than the type
        raise SystemExit(
            f"Kaggle authentication failed: {error}\n"
            "Run 'kaggle auth login', or set KAGGLE_API_TOKEN, or save your token to "
            "~/.kaggle/access_token (https://www.kaggle.com/settings/api)."
        ) from error
    return api


def is_rate_limited(error: Exception) -> bool:
    from kaggle.api.kaggle_api_extended import KaggleApi

    return KaggleApi._is_rate_limited(error)


def http_status(error: Exception) -> int | None:
    response = getattr(error, "response", None)
    return getattr(response, "status_code", None) if response is not None else None


def validate_submission(path: Path, track: str, config: dict) -> pd.DataFrame:
    """Catch a malformed file before it costs a submission from the daily quota.

    Kaggle counts a submission against the quota even when it fails to score, and the fan-out
    means one bad file would burn one on every competition of the track.
    """
    if config["tracks"][track]["family"] in ("mhr", "object_mesh"):
        if path.suffix.lower() != ".parquet":
            raise SystemExit(f"{path}: {track} requires a Parquet submission")
        try:
            frame = pd.read_parquet(path)
        except Exception as error:  # noqa: BLE001
            raise SystemExit(f"{path}: could not be read as Parquet ({error})") from error
        required = ["row_id", "x", "y", "z", "code_commit_url"]
        if list(frame.columns) != required:
            raise SystemExit(f"{path}: expected columns {required}, got {list(frame.columns)}")
        sample = ROOT / "data" / f"{track}_sample_submission.parquet"
        if not sample.exists():
            sample = ROOT / "build" / "kaggle" / rs.track_folder(track) / "sample_submission.parquet"
        if not sample.exists():
            raise SystemExit(f"{sample}: public sample is missing; cannot verify submission rows")
        expected = pd.read_parquet(sample, columns=["row_id"])["row_id"]
        if not frame["row_id"].equals(expected):
            raise SystemExit(f"{path}: row_id values or order differ from {sample}")
        if not np.isfinite(frame[["x", "y", "z"]].to_numpy(dtype=np.float64)).all():
            raise SystemExit(f"{path}: contains a null, NaN or infinite coordinate")
        commits = frame["code_commit_url"].astype(str).str.strip()
        if commits.nunique() != 1 or not re.match(rs.CODE_COMMIT_PATTERN, commits.iloc[0]):
            raise SystemExit(f"{path}: code_commit_url must be one GitHub commit URL on every row")
        return frame

    if path.suffix.lower() != ".csv":
        raise SystemExit(f"{path}: {track} requires a CSV submission")
    try:
        frame = pd.read_csv(path)
    except Exception as error:  # noqa: BLE001
        raise SystemExit(f"{path}: could not be read as CSV ({error})") from error

    missing = [c for c in (rs.ROW_ID_COLUMN, *SUBMISSION_COLUMNS) if c not in frame.columns]
    if missing:
        raise SystemExit(
            f"{path}: missing column(s) {missing}.\n"
            f"Build the file with: python tools/pack_submission.py --track {track} "
            "--results <dir> -o submission.csv"
        )
    if len(frame) == 0:
        raise SystemExit(f"{path}: has no rows")
    if frame[rs.ROW_ID_COLUMN].duplicated().any():
        first = frame.loc[frame[rs.ROW_ID_COLUMN].duplicated(), rs.ROW_ID_COLUMN].iloc[0]
        raise SystemExit(f"{path}: duplicate {rs.ROW_ID_COLUMN} values, first is '{first}'")
    row_prefix = f"track_{rs.track_number(track)}/"
    if not frame[rs.ROW_ID_COLUMN].astype(str).str.startswith(row_prefix).all():
        raise SystemExit(
            f"{path}: not every row_id belongs to {track}. Did you pass the wrong --track?"
        )
    sample_name = "track_2_sample_submission.csv" if track.startswith("track_2_") else "track_3_sample_submission.csv"
    sample = ROOT / "data" / sample_name
    if not sample.exists():
        sample = ROOT / "build" / "kaggle" / rs.track_folder(track) / "sample_submission.csv"
    if not sample.exists():
        raise SystemExit(f"{sample}: public sample is missing; cannot verify submission rows")
    expected = pd.read_csv(sample, usecols=[rs.ROW_ID_COLUMN], dtype=str)[rs.ROW_ID_COLUMN]
    if not frame[rs.ROW_ID_COLUMN].astype(str).equals(expected):
        raise SystemExit(f"{path}: row_id values or order differ from {sample}")

    pose = frame[POSE_COLUMNS].to_numpy(dtype=np.float64, na_value=np.nan)
    if not np.all(np.isfinite(pose)):
        raise SystemExit(f"{path}: contains a null, NaN or infinite pose value")
    norms = np.linalg.norm(pose[:, 3:], axis=-1)
    if np.any(norms < 1e-8):
        raise SystemExit(f"{path}: contains a degenerate (near-zero-norm) quaternion")

    commit = frame["code_commit_url"].astype(str).str.strip().iloc[0]
    if not re.match(rs.CODE_COMMIT_PATTERN, commit):
        raise SystemExit(
            f"{path}: 'code_commit_url' must be a GitHub commit URL, for example\n"
            f"  https://github.com/<owner>/<repo>/commit/<sha>\n"
            f"got: {commit!r}"
        )

    for column in rs.PROVENANCE_COLUMNS:
        # isna() first: an empty CSV field is NaN, and str(NaN) == "nan", so testing the
        # stringified column for "" never fires. See the same fix in the Kaggle metric.
        if frame[column].isna().any():
            raise SystemExit(
                f"{path}: '{column}' is empty on {int(frame[column].isna().sum()):,} row(s). "
                "Kaggle rejects a submission containing nulls."
            )
        values = frame[column].astype(str).str.strip()
        if values.eq("").any() or values.isin({"nan", "None", "NaN"}).any():
            raise SystemExit(f"{path}: '{column}' is blank on at least one row")

    # Mirrors the host-side rule in the Kaggle metric: the evaluator digests and the commit are
    # uniform across the file, the checkpoint is uniform only within an episode. Policies here
    # are trained per sequence, so differing checkpoints between episodes are the normal case.
    for column in rs.UNIFORM_PROVENANCE_COLUMNS:
        values = frame[column].astype(str).str.strip()
        if values.nunique() != 1:
            raise SystemExit(
                f"{path}: '{column}' must be identical on every row; found {values.nunique()} "
                "distinct values. One submission is one evaluator build, run from one commit."
            )

    if "episode_index" in frame.columns:
        for column in rs.PER_EPISODE_PROVENANCE_COLUMNS:
            counts = frame.groupby("episode_index")[column].apply(
                lambda block: block.astype(str).str.strip().nunique()
            )
            offenders = sorted(counts[counts > 1].index.tolist())
            if offenders:
                raise SystemExit(
                    f"{path}: '{column}' must be identical within each episode; episode(s) "
                    f"{offenders[:5]} carry more than one value."
                )

    for column in rs.UNIFORM_PROVENANCE_COLUMNS:
        if column == "code_commit_url":
            continue
        accepted = [h.lower() for h in config.get(f"accepted_{column}", [])]
        reported = frame[column].astype(str).str.strip().iloc[0].lower()
        if accepted and reported not in accepted:
            raise SystemExit(
                f"{path}: {column} '{reported}' is not a released evaluator version.\n"
                f"Accepted: {accepted}\nRe-run with the official evaluate_policy.py."
            )
    return frame


class _Missing:
    """Kaggle reports no such competition.

    Distinct from ``None`` ("could not tell"), because those two demand opposite responses: an
    unknown status is advisory and falls through to the later guards, whereas a competition that
    does not exist can never be submitted to and must stop the run. Collapsing them let
    ``--check-entry`` report a typo'd or not-yet-created slug as ready to submit.
    """

    def __bool__(self) -> bool:
        return False

    def __repr__(self) -> str:
        return "MISSING"


MISSING = _Missing()


def entry_status(api, slug: str) -> bool | None | _Missing:
    """Has the caller entered this competition (i.e. accepted its rules)?

    ``True``/``False`` when Kaggle says so, ``MISSING`` when there is no such competition, and
    ``None`` when the call failed for some other reason.

    Kaggle has no endpoint to ACCEPT rules, so this cannot be automated away. It can at least be
    turned into a precise checklist instead of a participant discovering it one 403 at a time.
    """
    try:
        from kagglesdk.competitions.types.competition_api_service import ApiGetCompetitionRequest

        with api.build_kaggle_client() as client:
            request = ApiGetCompetitionRequest()
            request.competition_name = slug
            competition = client.competitions.competition_api_client.get_competition(request)
        return bool(getattr(competition, "user_has_entered", False))
    except Exception as error:  # noqa: BLE001 - advisory only; the 403 path below is the real guard
        if http_status(error) == 404:
            return MISSING
        return None


def report_missing_entries(competitions: dict[str, str], missing: list[str]) -> None:
    print("\nYou have not accepted the rules for:\n")
    for slug in missing:
        print(f"  https://www.kaggle.com/c/{slug}/rules")
    print(
        "\nOpen each one and click accept, then re-run. Kaggle has no API for this, so it is the\n"
        "one genuinely manual step. It is once per competition, not once per submission."
    )


def preflight(api, competitions: dict[str, str]) -> dict[str, dict]:
    """Check auth, rules acceptance, quota and identity on every competition."""
    info: dict[str, dict] = {}
    blocked: list[tuple[str, str]] = []
    not_entered: list[str] = []
    for metric, slug in competitions.items():
        entry: dict = {"slug": slug}
        entry["entered"] = entry_status(api, slug)
        if entry["entered"] is MISSING:
            blocked.append((slug, "competition not found (check the slug in config/tracks.json)"))
            info[metric] = entry
            continue
        if entry["entered"] is False:
            not_entered.append(slug)
        try:
            submissions = api.competition_submissions(slug, page_size=1) or []
            entry["team_name"] = next(
                (s.team_name for s in submissions if s is not None and s.team_name), None
            )
            entry["user"] = next(
                (s.submitted_by_ref for s in submissions if s is not None and getattr(s, "submitted_by_ref", None)),
                None,
            )
        except Exception as error:  # noqa: BLE001
            status = http_status(error)
            if status == 403:
                # A 403 from ListSubmissions proves nothing on its own. Measured against the
                # live API: it comes back for a competition the caller HAS entered, for one they
                # have not, and for one that does not exist. It is Kaggle's generic refusal, not
                # a diagnosis. Only call it a rules problem when the competition record agrees
                # the caller has not entered.
                if entry.get("entered") is False:
                    blocked.append((slug, "competition rules have not been accepted"))
                    not_entered.append(slug)
                    info[metric] = entry
                    continue
                # Entered, but Kaggle will not list submissions. Not fatal, and the quota is
                # still readable, so fall through rather than skipping the rest of the checks.
                entry["submissions_readable"] = False
            elif status == 404:
                blocked.append((slug, "competition not found (check the slug in config/tracks.json)"))
                info[metric] = entry
                continue
            else:
                blocked.append((slug, f"{type(error).__name__}: {error}"))
                info[metric] = entry
                continue

        try:
            limits = api.competition_get_submission_limits(slug)
            entry["remaining"] = getattr(limits, "num_allowed_now", None)
            entry["used_today"] = getattr(limits, "num_today", None)
        except Exception:  # noqa: BLE001 - quota is advisory, never a hard blocker
            entry["remaining"] = None
        info[metric] = entry

    if not_entered:
        print("Preflight failed. Nothing has been submitted.")
        report_missing_entries(competitions, not_entered)
        raise SystemExit(1)

    if blocked:
        print("Preflight failed. Nothing has been submitted.\n")
        for slug, reason in blocked:
            print(f"  {slug}: {reason}")
            if "rules" in reason:
                print(f"      accept them once at https://www.kaggle.com/c/{slug}/rules")
        raise SystemExit(1)

    unreadable = [e["slug"] for e in info.values() if e.get("submissions_readable") is False]
    if unreadable:
        print(
            "Note: Kaggle would not list your past submissions (HTTP 403) for "
            + ", ".join(unreadable)
            + ".\n      That response is uninformative on its own, so this is not necessarily a "
            "problem:\n      the same 403 comes back for competitions you have not entered and "
            "for ones that\n      do not exist. You are recorded as entered, so submitting "
            "should still work.\n      The identity check is skipped and --wait cannot poll "
            "these; read the leaderboard."
        )

    identities = {
        (entry.get("user"), entry.get("team_name"))
        for entry in info.values()
        if entry.get("user") or entry.get("team_name")
    }
    if len(identities) > 1:
        print("Your Kaggle identity is not the same on every leaderboard of this track.\n")
        for metric, entry in info.items():
            print(f"  {entry['slug']:40s} user={entry.get('user')!r} team={entry.get('team_name')!r}")
        raise SystemExit(
            "\nThe pooled leaderboard on the challenge site joins these competitions on your\n"
            "identity, so a mismatch would list you twice. Rename your team so it matches\n"
            "across all of them, then re-run."
        )

    exhausted = [e["slug"] for e in info.values() if e.get("remaining") == 0]
    if exhausted:
        print("Warning: today's submission quota is already used up on: " + ", ".join(exhausted))
    return info


def submit_one(api, slug: str, path: Path, message: str, quiet: bool) -> str:
    delay = _BACKOFF_BASE_SECONDS
    for attempt in range(_MAX_RATE_LIMIT_RETRIES):
        try:
            response = api.competition_submit(str(path), message, slug, quiet=True)
            return getattr(response, "message", "") or "submitted"
        except Exception as error:  # noqa: BLE001
            if is_rate_limited(error) and attempt < _MAX_RATE_LIMIT_RETRIES - 1:
                if not quiet:
                    print(f"      rate limited, retrying in {delay:.0f}s")
                time.sleep(delay)
                delay *= 2
                continue
            raise
    raise RuntimeError("unreachable")


def wait_for_scores(api, competitions: dict[str, str]) -> int:
    print("\nWaiting for scores...")
    pending = dict(competitions)
    deadline = time.monotonic() + _POLL_TIMEOUT_SECONDS
    failures = 0
    while pending and time.monotonic() < deadline:
        time.sleep(_POLL_SECONDS)
        for metric, slug in list(pending.items()):
            try:
                submissions = api.competition_submissions(slug, page_size=1) or []
            except Exception as error:  # noqa: BLE001
                status = http_status(error)
                reason = ("Kaggle will not list submissions for this competition (HTTP 403)"
                          if status == 403 else str(error))
                print(f"  {metric:16s} cannot poll ({reason}); check the leaderboard")
                del pending[metric]
                continue
            latest = next((s for s in submissions if s is not None), None)
            if latest is None:
                continue
            status = str(getattr(latest, "status", "")).upper()
            if "PENDING" in status:
                continue
            del pending[metric]
            if "ERROR" in status:
                failures += 1
                print(f"  {metric:16s} ERROR: {latest.error_description}")
            else:
                print(f"  {metric:16s} {latest.public_score}")
    for metric in pending:
        print(f"  {metric:16s} still pending after {_POLL_TIMEOUT_SECONDS}s; check the site")
    return failures


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("submission", type=Path, nargs="?",
                        help="the packed CSV or Parquet; omit with --check-entry")
    parser.add_argument("--track", required=True)
    parser.add_argument("-m", "--message", help="submission description, shown on Kaggle")
    parser.add_argument("--only", nargs="+", metavar="METRIC", help="submit to a subset of the metrics")
    parser.add_argument("--wait", action="store_true", help="poll until every leaderboard has scored")
    parser.add_argument("--dry-run", action="store_true", help="validate and preflight, do not submit")
    parser.add_argument("--check-entry", action="store_true",
                        help="report which of this track's competitions you still need to accept "
                             "rules for, then stop")
    parser.add_argument("--config", type=Path, default=CONFIG)
    args = parser.parse_args()

    if not args.check_entry and (args.submission is None or args.message is None):
        raise SystemExit("a submission file and -m/--message are required unless --check-entry is used")

    config = json.loads(args.config.read_text())
    if args.track not in config["tracks"]:
        raise SystemExit(f"unknown track {args.track!r}; known: {sorted(config['tracks'])}")
    spec = config["tracks"][args.track]

    competitions = dict(spec["competitions"])
    if args.only:
        unknown = [m for m in args.only if m not in competitions]
        if unknown:
            raise SystemExit(f"unknown metric(s) {unknown}; known: {sorted(competitions)}")
        competitions = {m: competitions[m] for m in args.only}

    if args.check_entry:
        api = build_api()
        status = {slug: entry_status(api, slug) for slug in competitions.values()}
        absent = [slug for slug, state in status.items() if state is MISSING]
        if absent:
            print("These competitions do not exist. Nothing else was checked.\n")
            for slug in absent:
                print(f"  {slug}")
            print(
                "\nEither the slug in config/tracks.json is wrong, or the competition has not been\n"
                "created yet. A competition that does not exist cannot be submitted to."
            )
            return 1
        missing = [slug for slug, state in status.items() if state is False]
        if missing:
            report_missing_entries(competitions, missing)
            return 1
        print(f"{spec['title']}: all {len(competitions)} competition(s) entered. You are ready to submit.")
        return 0

    if not args.submission.exists():
        raise SystemExit(f"{args.submission}: no such file")
    frame = validate_submission(args.submission, args.track, config)
    if spec["family"] == "mhr":
        episodes = frame[rs.ROW_ID_COLUMN].astype(str).str.extract(r"^t1_(\d+)_")[0].nunique()
    elif spec["family"] == "object_mesh":
        episodes = frame[rs.ROW_ID_COLUMN].astype(str).str.extract(r"^t3m_(\d+)_")[0].nunique()
    else:
        episodes = frame[rs.ROW_ID_COLUMN].astype(str).str.split("/").str[1].nunique()
    print(f"{args.submission}: {len(frame):,} rows over {episodes} episodes, "
          f"{args.submission.stat().st_size:,} B - looks valid")
    print(f"{spec['title']}: {len(competitions)} leaderboard(s)")

    api = build_api()
    info = preflight(api, competitions)
    for metric, entry in info.items():
        remaining = entry.get("remaining")
        quota = f"{remaining} left today" if remaining is not None else "quota unknown"
        print(f"  {metric:16s} {entry['slug']:40s} {quota}")

    if args.dry_run:
        print("\n--dry-run: nothing submitted.")
        return 0

    failed: list[str] = []
    print()
    for metric, slug in competitions.items():
        try:
            result = submit_one(api, slug, args.submission, args.message, quiet=False)
            print(f"  {metric:16s} OK   {result}")
        except Exception as error:  # noqa: BLE001
            failed.append(metric)
            print(f"  {metric:16s} FAIL {type(error).__name__}: {error}")

    if failed:
        retry = " ".join(failed)
        print(
            f"\n{len(failed)} of {len(competitions)} submissions failed. "
            f"Your leaderboards are now out of sync. Retry just those with:\n\n"
            f"  python {Path(__file__).name} {args.submission} --track {args.track} "
            f"-m {args.message!r} --only {retry}\n"
        )
        return 1

    print(f"\nAll {len(competitions)} submissions accepted.")
    if args.wait:
        return 1 if wait_for_scores(api, competitions) else 0
    print("Scores appear within a few minutes. Re-run with --wait to poll.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
