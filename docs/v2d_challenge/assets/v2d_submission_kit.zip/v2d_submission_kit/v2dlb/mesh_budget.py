"""Fit an object mesh to a submission's fixed face and vertex budget.

Kaggle compares row sets, so every submitted object mesh has exactly the reference's number of
vertex and face rows. The host's solution builders and the participant's packers both go through
this one function, so a reference mesh and a participant's copy of the same file come out
identical. Needs trimesh and fast_simplification (host-side and in the participant kit; never in a
Kaggle metric).
"""

from __future__ import annotations

import numpy as np


def budget_mesh(path, faces: int, vertices: int) -> tuple[np.ndarray, np.ndarray]:
    """The object mesh decimated to at most `faces` faces, then padded to exactly the budget.

    The reference goes through the same budget a participant must, so both sides of CD-O and
    contact penetration score a mesh of the same resolution. At 4096 faces every pseudo-GT object
    stays within 0.83 mm mean surface deviation of full resolution (measured 2026-09-22).
    Vertices are welded first: the GLBs store one vertex per face corner, which would leave
    quadric decimation nothing to collapse.
    """
    import fast_simplification
    import trimesh

    mesh = trimesh.load(path, force="mesh", process=False)
    welded = trimesh.Trimesh(mesh.vertices, mesh.faces, process=True)
    v = np.asarray(welded.vertices, dtype=np.float64)
    f = np.asarray(welded.faces, dtype=np.int64)
    if len(f) > faces:
        v, f = fast_simplification.simplify(v, f, target_count=faces)
        v, f = np.asarray(v, dtype=np.float64), np.asarray(f, dtype=np.int64)
    if len(f) > faces or len(v) > vertices:
        raise ValueError(f"{path}: decimated to {len(v)} vertices / {len(f)} faces, "
                         f"over the {vertices} / {faces} budget")
    # Padding: a repeated vertex, and degenerate faces on it, which have zero area.
    v = np.concatenate([v, np.repeat(v[:1], vertices - len(v), axis=0)])
    f = np.concatenate([f, np.zeros((faces - len(f), 3), dtype=np.int64)])
    return v, f
