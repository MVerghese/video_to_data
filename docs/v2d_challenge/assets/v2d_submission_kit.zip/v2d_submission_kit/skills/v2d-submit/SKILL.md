---
name: v2d-submit
description: Submit Track 1 reconstructions, Track 2 grounding rollouts, and Track 3 end-to-end
  rollouts and object meshes to the V2D Challenge leaderboards. Covers packers, preflight, and
  the multi-leaderboard upload.
---

# Submitting to the V2D Challenge

Run every command from the kit root -- the directory holding `tools/`, `submit/` and `v2dlb/`.
Start with the guide for [Track 1](../../tracks/track_1/README.md),
[Track 2](../../tracks/track_2/README.md), or [Track 3](../../tracks/track_3/README.md).
The trajectory steps below apply to Track 2 and Track 3 pose submissions. Track 1 and Track 3
mesh submissions use `tools/pack_reconstruction.py` as described in their guides.

**A rejected submission still costs quota.** Kaggle counts it. So run the preflight first, every
time; it is cheap and it reports every problem at once instead of one upload at a time.

## Step 1. Preflight

```
python3 tools/preflight.py --track track_3 --results results/
```

Checks python and package versions, whether you are in a container, the Kaggle token, the
public sample (Track 3) or dataset (Track 2), that every scored episode has a trajectory, and that the user has accepted the rules on
every leaderboard of the track. **Do not proceed while it reports a blocking problem** -- fix
what it names and re-run. It exits non-zero when blocked.

Two failures it reports that you cannot fix by running anything:

- **Not registered.** There is no API to accept competition rules. The user must open each
  leaderboard URL the preflight prints and click accept. Once per competition, not per
  submission. Ask them to do it; do not try to automate it.
- **No Kaggle token.** They need one from <https://kaggle.com/settings/api>, then
  `export KAGGLE_API_TOKEN=<token>`. A legacy `~/.kaggle/kaggle.json` does **not** work with
  kaggle>=2; the preflight says so explicitly if it finds one.

## Step 2. What the packer expects

`--results` is a directory of the organiser evaluator's output, one file per scored episode:

```
results/
  episode_000007.parquet     the rolled-out object trajectory   REQUIRED
  episode_000007.json        the evaluator's own metrics        optional, cross-checked
```

Filenames must be `episode_<6-digit index>.parquet`, and the indices must match the scored
episodes of the track. The preflight names any that are missing.

**Checkpoints.** Each parquet records the checkpoint that produced it, in its schema metadata.
This challenge trains **one policy per sequence**, so a submission normally carries a *different*
checkpoint for every episode. That is expected and is not an error. The rules are:

- `checkpoint_sha256` must be identical *within* an episode, and may differ *between* episodes.
- `eval_script_sha256`, `eval_code_sha256`, `packer_script_sha256`,
  `uploader_script_sha256` and `code_commit_url` must be identical across the
  whole file. One submission is one evaluator build, run from one commit.
- None of them may be blank. A single empty cell makes Kaggle reject the whole submission.

If the parquets predate the provenance change and carry no evaluator hash, pass
`--eval-script /path/to/evaluate_policy.py` and the packer will hash it.

## Step 3. Pack

```
python3 tools/pack_submission.py --track track_3     --results results/     --code-commit https://github.com/<owner>/<repo>/commit/<sha>     -o submission.csv
```

`--code-commit` is required and must be a `/commit/<sha>` URL. A branch or tag moves, so neither
identifies what was run. It must point at a repository shared with the V2D organisers.

The packer verifies frame alignment and object ordering, then **recomputes every leaderboard
metric locally for Track 2, using its public reference. Track 3 has confidential reference poses,
so the packer validates against the bundled public row roster but cannot print held-out scores.
Record local Track 2 numbers and compare them with Kaggle after submission.

For Track 1 and Track 3's separate CD-O mesh leaderboard, use
`tools/pack_reconstruction.py` with the public sample Parquet. Then pass the resulting Parquet
to `submit/v2d_submit.py` with `--track track_1` or `--track track_3_mesh`.

## Step 4. Submit

```
python3 submit/v2d_submit.py submission.csv --track track_3 -m "<short description>"
```

One file, every leaderboard of the track. All competitions are preflighted before anything is
sent, so an unaccepted rules page fails before the first upload rather than halfway through.

If a leg fails, the error prints a `--only <metric>` command that retries just that leaderboard.
Use it rather than resubmitting everything; the others already succeeded and would each cost
another submission.

Scores appear on Kaggle within a few minutes. The pooled table on the challenge site can lag by
up to 24 hours, which is expected and not a fault.

## The leaderboards

### track_1

5 leaderboards. The SAME submission file goes to every one.

| Metric | Better | Competition |
|---|---|---|
|   CD-H   | lower  | [v2d-challenge-track1-cd-h](https://www.kaggle.com/competitions/v2d-challenge-track1-cd-h/leaderboard) |
|   CD-O   | lower  | [v2d-challenge-track1-cd-o](https://www.kaggle.com/competitions/v2d-challenge-track1-cd-o/leaderboard) |
|   ACC-H  | lower  | [v2d-challenge-track1-acc-h](https://www.kaggle.com/competitions/v2d-challenge-track1-acc-h/leaderboard) |
|   ACC-O  | lower  | [v2d-challenge-track1-acc-o](https://www.kaggle.com/competitions/v2d-challenge-track1-acc-o/leaderboard) |
|   PEN    | lower  | [v2d-challenge-track1-pen](https://www.kaggle.com/competitions/v2d-challenge-track1-pen/leaderboard) |

### track_2_tier1

4 leaderboards. The SAME submission file goes to every one.

| Metric | Better | Competition |
|---|---|---|
|   AUC    | higher | [v2d-challenge-track2-tier1-auc](https://www.kaggle.com/competitions/v2d-challenge-track2-tier1-auc/leaderboard) |
|   SP-SR  | higher | [v2d-challenge-track2-tier1-sp-sr](https://www.kaggle.com/competitions/v2d-challenge-track2-tier1-sp-sr/leaderboard) |
|   MP-SR  | higher | [v2d-challenge-track2-tier1-mp-sr](https://www.kaggle.com/competitions/v2d-challenge-track2-tier1-mp-sr/leaderboard) |
|   MPPE   | lower  | [v2d-challenge-track2-tier1-mppe](https://www.kaggle.com/competitions/v2d-challenge-track2-tier1-mppe/leaderboard) |

### track_2_tier2

4 leaderboards. The SAME submission file goes to every one.

| Metric | Better | Competition |
|---|---|---|
|   AUC    | higher | [v2d-challenge-track2-tier2-auc](https://www.kaggle.com/competitions/v2d-challenge-track2-tier2-auc/leaderboard) |
|   SP-SR  | higher | [v2d-challenge-track2-tier2-sp-sr](https://www.kaggle.com/competitions/v2d-challenge-track2-tier2-sp-sr/leaderboard) |
|   MP-SR  | higher | [v2d-challenge-track2-tier2-mp-sr](https://www.kaggle.com/competitions/v2d-challenge-track2-tier2-mp-sr/leaderboard) |
|   MPPE   | lower  | [v2d-challenge-track2-tier2-mppe](https://www.kaggle.com/competitions/v2d-challenge-track2-tier2-mppe/leaderboard) |

### track_2_tier3

4 leaderboards. The SAME submission file goes to every one.

| Metric | Better | Competition |
|---|---|---|
|   AUC    | higher | [v2d-challenge-track2-tier3-auc](https://www.kaggle.com/competitions/v2d-challenge-track2-tier3-auc/leaderboard) |
|   SP-SR  | higher | [v2d-challenge-track2-tier3-sp-sr](https://www.kaggle.com/competitions/v2d-challenge-track2-tier3-sp-sr/leaderboard) |
|   MP-SR  | higher | [v2d-challenge-track2-tier3-mp-sr](https://www.kaggle.com/competitions/v2d-challenge-track2-tier3-mp-sr/leaderboard) |
|   MPPE   | lower  | [v2d-challenge-track2-tier3-mppe](https://www.kaggle.com/competitions/v2d-challenge-track2-tier3-mppe/leaderboard) |

### track_3

5 leaderboards. The SAME submission file goes to every one.

| Metric | Better | Competition |
|---|---|---|
|   AUC    | higher | [v2d-challenge-track3-auc](https://www.kaggle.com/competitions/v2d-challenge-track3-auc/leaderboard) |
|   SP-SR  | higher | [v2d-challenge-track3-sp-sr](https://www.kaggle.com/competitions/v2d-challenge-track3-sp-sr/leaderboard) |
|   MP-SR  | higher | [v2d-challenge-track3-mp-sr](https://www.kaggle.com/competitions/v2d-challenge-track3-mp-sr/leaderboard) |
|   RPE    | lower  | [v2d-challenge-track3-rpe](https://www.kaggle.com/competitions/v2d-challenge-track3-rpe/leaderboard) |
|   MPPE   | lower  | [v2d-challenge-track3-mppe](https://www.kaggle.com/competitions/v2d-challenge-track3-mppe/leaderboard) |

### track_3_mesh

1 leaderboards. The SAME submission file goes to every one.

| Metric | Better | Competition |
|---|---|---|
|   CD-O   | lower  | [v2d-challenge-track3-cd-o](https://www.kaggle.com/competitions/v2d-challenge-track3-cd-o/leaderboard) |


## Things not to do

- Do not hand-build the submission CSV. The packer checks frame alignment and object ordering,
  and both are easy to get subtly wrong in ways that score badly rather than failing.
- Do not submit the same rollout to a tier it was not produced for, where a track has input
  tiers. Every tier is scored against the same reference, so nothing in the file distinguishes
  them, and doing so is a rules violation.
- Do not retry a failed submission by resubmitting the whole file unless every leaderboard failed.
